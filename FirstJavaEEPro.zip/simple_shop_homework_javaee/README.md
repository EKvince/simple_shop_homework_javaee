# simple_shop_homework_javaee
java EE选修课小作业 商城项目
使用javaEE+tomcat开发的商城项目作业
使用了JSP和servlet两种不同的方式实现

-----------------
### 一些错误
tomcat10不再支持javax，而改为支持另一个组件，要在pom文件中修改依赖才能正常运行
