//package com.example.FirstJavaEEPro;
//
//import javax.ws.rs.ApplicationPath;
//import javax.ws.rs.core.Application;
//
//@ApplicationPath("/")
//public class HelloApplication extends Application {
//
//}